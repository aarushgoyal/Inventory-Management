// ==========================================================
// Paste your own Supabase project details below.
// Find them in: Supabase dashboard → Project Settings → API
//   - "Project URL"        -> SUPABASE_URL
//   - "anon public" key    -> SUPABASE_ANON_KEY
// The anon key is safe to expose in client-side code; access is
// controlled by the Row Level Security policies in schema.sql.
// ==========================================================
const SUPABASE_URL = "https://YOUR-PROJECT-ID.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-PUBLIC-KEY";
